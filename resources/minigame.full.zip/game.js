import "./weapp-adapter";
import Loader from "./js/loader";

const loader = new Loader();
loader.load();
